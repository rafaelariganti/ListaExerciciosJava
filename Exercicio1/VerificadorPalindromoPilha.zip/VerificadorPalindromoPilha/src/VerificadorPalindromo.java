import javax.swing.*;
import java.awt.*;
import exemplopilha.Pilha;

public class VerificadorPalindromo extends JFrame {

    private JTextField campoTexto;
    private final JButton botaoVerificar;
    private JLabel resultado;

    public VerificadorPalindromo() {
        setTitle("Verificador de Palíndromos");
        setSize(350, 200);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new FlowLayout());

        campoTexto = new JTextField(20);
        botaoVerificar = new JButton("Verificar");
        resultado = new JLabel("");

        add(new JLabel("Digite uma palavra:"));
        add(campoTexto);
        add(botaoVerificar);
        add(resultado);

        botaoVerificar.addActionListener(e -> {
            String palavra = campoTexto.getText();
            boolean ehPalindromo = ehPalindromo(palavra);

            if (ehPalindromo) {
                resultado.setText("É um palíndromo!");
            } else {
                resultado.setText("Não é um palíndromo.");
            }
        });
    }

    // Usando a pilha.java
    public static boolean ehPalindromo(String palavra) {
        // Removedo espaços e diferenciando minuscula de maiscula
        palavra = palavra.replaceAll(" ", "").toLowerCase();

        Pilha pilha = new Pilha(palavra.length());

     
        for (int i = 0; i < palavra.length(); i++) {
            pilha.empilhar(palavra.charAt(i));
        }

        // Verificando se a palavra é igual de tras para frente 
        for (int i = 0; i < palavra.length(); i++) {
            char c = (char) pilha.desempilhar();
            if (palavra.charAt(i) != c) {
                return false;
            }
        }

        return true;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new VerificadorPalindromo().setVisible(true));
    }
}
