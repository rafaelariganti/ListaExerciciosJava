    import javax.swing.*;
    import java.awt.*;
    import java.util.ArrayList;
    import java.util.Collections;

    public class CadastroNomes extends JFrame {

        private ArrayList<String> nomes;
        private JTextArea listaNomes;
        private JTextField nomeField;

        public CadastroNomes() {
            nomes = new ArrayList<>();

            setTitle("Cadastro de Nomes");
            setSize(400, 400);
            setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            setLocationRelativeTo(null);
            setLayout(new BorderLayout(10, 10));

            
            JPanel painelSuperior = new JPanel();
            painelSuperior.setLayout(new BoxLayout(painelSuperior, BoxLayout.Y_AXIS));

            
            JPanel panelInput = new JPanel(new FlowLayout());
            nomeField = new JTextField(20);
            panelInput.add(new JLabel("Nome:"));
            panelInput.add(nomeField);

           
            JPanel panelButtons = new JPanel(new FlowLayout());
            JButton btnAdicionar = new JButton("Adicionar");
            JButton btnRemover = new JButton("Remover");
            JButton btnListar = new JButton("Listar");
            JButton btnBuscar = new JButton("Buscar");
            panelButtons.add(btnAdicionar);
            panelButtons.add(btnRemover);
            panelButtons.add(btnListar);
            panelButtons.add(btnBuscar);

            painelSuperior.add(panelInput);
            painelSuperior.add(panelButtons);

            // Área de listagem
            listaNomes = new JTextArea(12, 30); 
            listaNomes.setEditable(false);
            JScrollPane scrollPane = new JScrollPane(listaNomes);

            // Adicionando os componentes na janela
            add(painelSuperior, BorderLayout.NORTH);
            add(scrollPane, BorderLayout.CENTER);

          
            btnAdicionar.addActionListener(e -> {
                String nome = nomeField.getText().trim();
                if (!nome.isEmpty()) {
                    nomes.add(nome);
                    nomeField.setText("");
                    JOptionPane.showMessageDialog(this, "Nome adicionado!");
                    listaNomes.setText(""); 
                } else {
                    JOptionPane.showMessageDialog(this, "Digite um nome válido!");
                }
            });

            btnRemover.addActionListener(e -> {
                String nome = nomeField.getText().trim();
                if (nomes.remove(nome)) {
                    nomeField.setText("");
                    JOptionPane.showMessageDialog(this, "Nome removido!");
                } else {
                    JOptionPane.showMessageDialog(this, "Nome não encontrado.");
                }
                listaNomes.setText(""); 
            });

            btnListar.addActionListener(e -> {
                if (nomes.isEmpty()) {
                    listaNomes.setText("Lista vazia.");
                } else {
                    Collections.sort(nomes);
                    StringBuilder sb = new StringBuilder("Nomes cadastrados:\n\n");
                    for (String nome : nomes) {
                        sb.append("• ").append(nome).append("\n");
                    }
                    listaNomes.setText(sb.toString());
                }
            });

            btnBuscar.addActionListener(e -> {
                String nome = nomeField.getText().trim();
                if (nomes.contains(nome)) {
                    JOptionPane.showMessageDialog(this, "Nome encontrado!");
                } else {
                    JOptionPane.showMessageDialog(this, "Nome não encontrado.");
                }
            });
        }

        public static void main(String[] args) {
            SwingUtilities.invokeLater(() -> new CadastroNomes().setVisible(true));
        }
    }