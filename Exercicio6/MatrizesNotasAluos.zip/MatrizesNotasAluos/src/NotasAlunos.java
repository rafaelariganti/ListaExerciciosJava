import java.util.Scanner;

public class NotasAlunos {

    public static void main(String[] args) {
        // Usando try-with-resources para garantir que o scanner seja fechado automaticamente
        try (Scanner scanner = new Scanner(System.in)) {
            // Definindo uma matriz para armazenar as notas dos 5 alunos (5 alunos e 3 provas cada)
            double[][] notas = new double[5][3];
            double[] medias = new double[5];  // Armazenar as médias de cada aluno

            // Lendo as notas e calculando as médias
            for (int i = 0; i < 5; i++) {
                System.out.println("Digite as 3 notas do aluno " + (i + 1) + ":");
                double soma = 0;
                for (int j = 0; j < 3; j++) {
                    System.out.print("Nota " + (j + 1) + ": ");
                    notas[i][j] = scanner.nextDouble();
                    soma += notas[i][j];  // Somando as notas para calcular a média
                }
                medias[i] = soma / 3;  // Calculando a média do aluno
            }

            double maiorMedia = medias[0];  // Inicializando a maior e menor média
            double menorMedia = medias[0];

            System.out.println("\n--- MÉDIAS DOS ALUNOS ---");

            // Mostrando as médias e a situação (aprovado ou reprovado) de cada aluno
            for (int i = 0; i < 5; i++) {
                System.out.printf("Aluno %d: Média = %.2f", i + 1, medias[i]);
                if (medias[i] >= 7.0) {
                    System.out.println(" (Aprovado)");
                } else {
                    System.out.println(" (Reprovado)");
                }

                // Atualizando as maior e menor médias
                if (medias[i] > maiorMedia) maiorMedia = medias[i];
                if (medias[i] < menorMedia) menorMedia = medias[i];
            }

            // Exibindo a maior e a menor média
            System.out.printf("\nMaior media: %.2f\n", maiorMedia);
            System.out.printf("Menor media: %.2f\n", menorMedia);
        }
    }
}
